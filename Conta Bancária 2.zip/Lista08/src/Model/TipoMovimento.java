
package Model;

public enum TipoMovimento {
    DEBITO,
    CREDITO;
}
