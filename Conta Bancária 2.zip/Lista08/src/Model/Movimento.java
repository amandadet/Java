
package Model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Movimento {
    private double valor;
    private TipoMovimento tipoMovimento;
    private LocalDate data;
    private LocalTime hora;

    Movimento(double valor, TipoMovimento tipoMovimento) {
       this.valor = valor;
       this.tipoMovimento = tipoMovimento;
       this.data = LocalDate.now();
       this.hora = LocalTime.now();
    }
    
    public LocalDate getData() {
        return this.data;
    }

    public LocalTime getHora() {
       return this.hora;
    }
 
    public double getValor() {
        return valor;
    }
    
    public TipoMovimento getTipoMovimento(){
        return this.tipoMovimento;
    }

     
}
