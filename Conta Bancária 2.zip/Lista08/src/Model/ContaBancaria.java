
package Model;

import java.util.ArrayList;

public class ContaBancaria {
    private String numero;
    private double saldo;
    private Titular titular;
    private ArrayList<Movimento> movimentos = new ArrayList<>();
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Titular getTitular() {
        return titular;
    }

    public void setTitular(Titular titular) {
        this.titular = titular;
    }

    public ArrayList<Movimento> getMovimentos() {
        return movimentos;
    }

    public void depositar(double valor){
        if (valor<=0){
            throw new RuntimeException("O valor depositado precisa ser maior do que 0! ");
        } else {
            this.saldo+=valor;
            Movimento mov = new Movimento(valor , TipoMovimento.CREDITO);
        }
    }
    
    public void sacar(double valor){
        if (valor<=0 || saldo<valor){
            throw new RuntimeException("O valor sacado precisa ser maior do que 0! ");
        } else {
            this.saldo-=valor;
            Movimento mov = new Movimento(valor , TipoMovimento.DEBITO);
        }
    }
    
    public void transferir(ContaBancaria c1 ,double valor){
        this.sacar(valor);
        c1.depositar(valor);
    }
    
     
}
