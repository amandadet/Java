
package Model;

public class ContaEspecial extends ContaBancaria {
    private double limiteCredito;

    public double getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(double limiteCredito) {
        this.limiteCredito = limiteCredito;
    }
    
    @Override
    public void sacar(double valor){
        if (valor<=0 || (this.getSaldo() + this.getLimiteCredito())<valor){
            throw new RuntimeException("O valor sacado precisa ser maior do que 0! ");
        } else {
            this.setSaldo(this.getSaldo()-valor);
        }
    }
}
