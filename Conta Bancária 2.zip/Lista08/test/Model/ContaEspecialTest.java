
package Model;

import org.junit.Test;
import static org.junit.Assert.*;

public class ContaEspecialTest {
    
    public ContaEspecialTest() {
    }

    @Test
    public void caso1ConferirSeMetodoSacarPermiteSacarValorSuperiorAoSaldo() {
        ContaEspecial ce = new ContaEspecial();
        ce.setLimiteCredito(100.00);
        ce.depositar(20.00);
        ce.sacar(50.00);
        double result = ce.getSaldo();
        assertEquals( -30.00, result, 0.01);
    }
    
    @Test
    public void caso2ConferirSeMetodoSacarPermiteSacarValorSuperiorAoSaldoMasInferiorAoLimiteDeCrédito() {
        ContaEspecial ce = new ContaEspecial();
        ce.setLimiteCredito(100.00);
        ce.depositar(20.00);
        ce.sacar(120.00);
        double result = ce.getSaldo();
        assertEquals( -100.00, result, 0.01);
    }
    
    @Test(expected = RuntimeException.class)
    public void caso3ConferirSeMetodoSacarImpedeSacarValorSuperiorELimiteDeCrédito() {
        ContaEspecial ce = new ContaEspecial();
        ce.setLimiteCredito(100.00);
        ce.depositar(20.00);
        ce.sacar(120.01);
    }
}
