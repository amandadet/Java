import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;
import br.furb.furbot.Numero;

public class Lista2Ex15 extends Furbot {

	public void inteligencia() throws Exception {
		diga("nasci em: " + getX() + " ," + getY());

		// s� falta saber como pego o valor dos numeros

		// usa eh objeto do mundo do tipo numero p ver se tem numero
		// getObjeto(DIREITA) p pegar valor
		// o valor vem como string, logo tenho que converter para somar

		int somaNumeroDireita = 0;
		int somaNumeroAbaixo = 0;
		int somaNumeroEsquerda = 0;
		int somaNumeroAcima = 0;
		int totalLIinhas = 0;

		Numero personagemNumero = new Numero();

		// somo os numeros direita

		while (!ehFim(DIREITA)) {
			if (!ehVazio(DIREITA)) {
				if (ehObjetoDoMundoTipo("Numero", DIREITA) == true) {
					personagemNumero = getObjeto(DIREITA);
					String valorDoPersonagem = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem);
					somaNumeroDireita = somaNumeroDireita + valor;
				}
			}
			andarDireita();
		}
		diga("Total da linha direita: " + somaNumeroDireita);

		// vejo se n�o tem um n�mero na primeria posicao da coluna que vai descer abaixo
		// se tiver, devo soma-lo na coluna abaixo tbm
		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO) == true) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem);
			somaNumeroAbaixo = somaNumeroAbaixo + valor;
		}

		// somo os numeros abaixo
		while (!ehFim(ABAIXO)) {
			if (!ehVazio(ABAIXO)) {
				if (ehObjetoDoMundoTipo("Numero", ABAIXO) == true) {
					personagemNumero = getObjeto(ABAIXO);
					String valorDoPersonagem = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem);
					somaNumeroAbaixo = somaNumeroAbaixo + valor;
				}

			}
			andarAbaixo();
		}
		diga("Total da linha abaixo: " + somaNumeroAbaixo);

		// verifico se n�o tem um numero na primeira posicao da coluna que segue para
		// esquerda
		// se tiver, somo-o na coluna da esquerda

		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO) == true) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem);
			somaNumeroEsquerda = somaNumeroEsquerda + valor;
		}

		// somo os numeros esquerda
		while (!ehFim(ESQUERDA)) {
			if (!ehVazio(ESQUERDA)) {
				if (ehObjetoDoMundoTipo("Numero", ESQUERDA) == true) {
					personagemNumero = getObjeto(ESQUERDA);
					String valorDoPersonagem = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem);
					somaNumeroEsquerda = somaNumeroEsquerda + valor;

				}

			}
			andarEsquerda();
		}
		diga("Total da linha esquerda: " + somaNumeroEsquerda);

		// verifico se n�o tem um numero na primeira posicao da LINHA que segue para
		// cima
		// se tiver, somo-o na linha do acima

		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO) == true) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem);
			somaNumeroAcima = somaNumeroAcima + valor;

		}

		// somo os numeros acima
		while (!ehFim(ACIMA)) {
			if (!ehVazio(ACIMA)) {
				if (ehObjetoDoMundoTipo("Numero", ACIMA) == true) {
					personagemNumero = getObjeto(ACIMA);
					String valorDoPersonagem = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem);
					somaNumeroAcima = somaNumeroAcima + valor;

				}
			}
			andarAcima();
		}
		diga("Total da linha acima: " + somaNumeroAcima);
		diga(" ");
		diga("O total da soma de todas as linhas �: " + (somaNumeroAcima + somaNumeroAbaixo + somaNumeroDireita + somaNumeroEsquerda));
		
	}

	public ImageIcon buildImage() {
		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex15.xml");

	}

}
