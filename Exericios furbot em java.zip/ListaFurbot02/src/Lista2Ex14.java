import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Lista2Ex14 extends Furbot {
	public void inteligencia() throws Exception {
		
			int contadorAlien = 0;
			int iniX = getX();
			int iniY = getY();
			
			// se nascer no meio do tabuleiro, devo mandar o furbot ir para o canto!!!!
			while (!ehFim(ESQUERDA)) {
				if (!ehVazio(ESQUERDA)) {
					contadorAlien += 1;
				}
				andarEsquerda();
			}
			
			// inicio a volta 
			while (!ehFim(ABAIXO)) {
				if (!ehVazio(ABAIXO)) {
					contadorAlien +=1;
				}
				andarAbaixo();
			}
			
			while (!ehFim(DIREITA)) {
				if (!ehVazio(DIREITA)) {
					contadorAlien += 1;
				}
				andarDireita();
			}
			
			while (!ehFim(ACIMA)) {
				if (!ehVazio(ACIMA)) {
					contadorAlien += 1;
				}
				andarAcima();
			}
		
			while(!ehFim(ESQUERDA)) {
				if (!ehVazio(ESQUERDA)) {
					contadorAlien += 1;
				}
				andarEsquerda();
			}
			
			
			//o furbot volta para onde ele nasceu
			int lAtual = 0;
			while (lAtual < iniY) {
				if (!ehVazio(ABAIXO)) {
					contadorAlien += 1;
				}
				andarAbaixo();
				lAtual += 1;
			}
			
			int cAtual = 0;
			while (cAtual < iniX) {
				andarDireita();
				cAtual += 1;
			}
			
			// mostro a quantidade de aliens que eu achei
			if (contadorAlien == 1) {
				diga("S� 1 alien atrapalhou o meu caminho");
			} else {
				diga(contadorAlien + " aliens atrapalharam meu caminho");
			}
			
			
		}
		
	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex14.xml");
	}
}
