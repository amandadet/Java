import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

public class Lista2Ex13 extends Furbot {

	public void inteligencia() throws Exception {

		int contadorAlien = 0;

		while (!ehFim(DIREITA)) {
			if (!ehVazio(DIREITA)) {
				if (ehObjetoDoMundoTipo("Alien", DIREITA) == true) {
					contadorAlien += 1;
				}
			}
			andarDireita();
		}
		
		if (contadorAlien == 0) {
			diga("Nenhum Alien atrapalhou meu caminho!");
		}
		if (contadorAlien == 1) {
			diga("1 Alien atrapalhou meu caminho!");
		}
		if (contadorAlien == 2) {
			diga("2 Aliens atrapalharam meu caminho!");
		}
		if (contadorAlien == 3) {
			diga("3 Aliens atrapalharam meu caminho!");
		}
	
		diga("  ");

	}

	public ImageIcon buildImage() {
		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex13.xml");

	}

}
