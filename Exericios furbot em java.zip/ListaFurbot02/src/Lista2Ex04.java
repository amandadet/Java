import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

public class Lista2Ex04 extends Furbot {
	
	public void inteligencia() throws Exception {
		diga ("mundo de furbot");
		
		while (! ehFim(DIREITA)) {
			andarDireita();
			diga("Andei para direita!");
		} // fim while
		diga ("cheguei em : " + getX() + " ," + getY());
		
		while ((! ehFim(ABAIXO))) {
			andarAbaixo();
			diga("Andei abaixo");
		}// fim 2 while
		diga ("cheguei em : " + getX() + " ," + getY());	
			
		while (! ehFim(ESQUERDA)) {
			andarEsquerda();
			diga("Andei para esquerda!");
		}// fim 3 while
		diga ("cheguei em : " + getX() + " ," + getY());
		
		while (! ehFim(ACIMA)) {
			andarAcima();
			diga("Andei acima");
		}// fim 4 while
		diga ("cheguei em : " + getX() + " ," + getY());
		diga("Voltei para o inicio do mundo!");	
	}
	

	
    public ImageIcon buildImage() {      
          return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex04.xml");

	}

}