import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;
import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista2Ex16 extends Furbot {

	public void inteligencia() throws Exception {

		// VAI USAR ZIGUE ZAGUE HORIZONTAL CORRIGIR

		int controlaLinha = -1;
		int somaLinha0 = 0;
		int somaLinha1 = 0;
		int somaLinha2 = 0;
		int somaLinha3 = 0;
		int somaLinha4 = 0;
		int somaLinha5 = 0;
		int somaLinha6 = 0;
		int somaLinha7 = 0;
		Numero personagemNumero = new Numero();
		Numero personagemNumero1 = new Numero();
		boolean repetir;
		repetir = true;

		while (repetir == true && controlaLinha <= 7) {
			controlaLinha += 1;
			while (!ehFim(DIREITA)) {
				// soma para a a linha 0
				if (controlaLinha == 0) {
					if (!ehVazio(DIREITA)) {
						personagemNumero = getObjeto(DIREITA);
						String valorDoPersonagem0 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem0);
						somaLinha0 = somaLinha0 + valor;
					}

				}

				// soma para a linha 2
				if (controlaLinha == 2) {
					if (!ehVazio(DIREITA)) {
						personagemNumero = getObjeto(DIREITA);
						String valorDoPersonagem2 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem2);
						somaLinha2 = somaLinha2 + valor;
					}

				}

				// soma linha 4
				if (controlaLinha == 4) {
					if (!ehVazio(DIREITA)) {
						personagemNumero = getObjeto(DIREITA);
						String valorDoPersonagem4 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem4);
						somaLinha4 = somaLinha4 + valor;
					}

				}

				// soma para a linha 6
				if (controlaLinha == 6) {
					if (!ehVazio(DIREITA)) {
						personagemNumero = getObjeto(DIREITA);
						String valorDoPersonagem6 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem6);
						somaLinha6 = somaLinha6 + valor;
					}

				}
				andarDireita();

			} // while

			if (!ehFim(ABAIXO)) {
				controlaLinha += 1;
				andarAbaixo();

				// objetivo de somar o primeiro e ultimo n�mero das linhas ONDE O PERCURSO
				// COME�A ANDANDO P/ ESQUERDA
				if (!ehVazio(AQUIMESMO)) {

					if (controlaLinha == 1) {
						personagemNumero = getObjeto(AQUIMESMO);
						String valorDoPersonagem1 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem1);
						somaLinha1 = somaLinha1 + valor;
					}

					if (controlaLinha == 3) {
						personagemNumero = getObjeto(AQUIMESMO);
						String valorDoPersonagem3 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem3);
						somaLinha3 = somaLinha3 + valor;
					}

					if (controlaLinha == 5) {
						personagemNumero = getObjeto(AQUIMESMO);
						String valorDoPersonagem5 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem5);
						somaLinha5 = somaLinha5 + valor;
					}

					if (controlaLinha == 7) {
						personagemNumero = getObjeto(AQUIMESMO);
						String valorDoPersonagem7 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem7);
						somaLinha7 = somaLinha7 + valor;
					}

				}

				while (!ehFim(ESQUERDA)) {

					// soma para a a linha 1
					if (controlaLinha == 1) {
						if (!ehVazio(ESQUERDA)) {
							personagemNumero = getObjeto(ESQUERDA);
							String valorDoPersonagem1 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem1);
							somaLinha1 = somaLinha1 + valor;
						}

					}

					// soma para a linha 3
					if (controlaLinha == 3) {
						if (!ehVazio(ESQUERDA)) {
							personagemNumero = getObjeto(ESQUERDA);
							String valorDoPersonagem3 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem3);
							somaLinha3 = somaLinha3 + valor;
						}

					}

					if (controlaLinha == 5) {
						if (!ehVazio(ESQUERDA)) {
							personagemNumero = getObjeto(ESQUERDA);
							String valorDoPersonagem5 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem5);
							somaLinha5 = somaLinha5 + valor;
						}

					}

					// soma para a linha 7
					if (controlaLinha == 7) {
						if (!ehVazio(ESQUERDA)) {
							personagemNumero = getObjeto(ESQUERDA);
							String valorDoPersonagem7 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem7);
							somaLinha7 = somaLinha7 + valor;
						}

					}

					andarEsquerda();
				}

				if (!ehFim(ABAIXO)) {
					andarAbaixo();
					if (!ehVazio(AQUIMESMO)) {
						diga("hey");

						// soma p/ a linha que inicia andando a direita
						// a compara��o deve ser menos 1 pois s� iremos aumentar +1 no controla linha l�
						// em cima, e quando
						// passa por aqui, a linha � igual a o valor da linha onde o furbot est� -1

						// para a linha 2, entao comparamos se � == 1
						if (controlaLinha == 1) {
							personagemNumero = getObjeto(AQUIMESMO);
							String valorDoPersonagem2 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem2);
							somaLinha2 = somaLinha2 + valor;
							diga("oi");
						}

						if (controlaLinha == 3) {
							personagemNumero = getObjeto(AQUIMESMO);
							String valorDoPersonagem4 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem4);
							somaLinha4 = somaLinha4 + valor;
						}

						if (controlaLinha == 5) {
							personagemNumero = getObjeto(AQUIMESMO);
							String valorDoPersonagem6 = personagemNumero.toString();
							int valor = Integer.parseInt(valorDoPersonagem6);
							somaLinha6 = somaLinha6 + valor;
						}
					}

				} else {
					repetir = false;
				}
			} else {
				repetir = false;
			}
		} // while

		diga("soma linha 0 =  " + somaLinha0);
		diga("soma linha 1 =  " + somaLinha1);
		diga("soma linha 2 = " + somaLinha2);
		diga("soma linha 3 = " + somaLinha3);
		diga("soma linha 4 = " + somaLinha4);
		diga("soma linha 5 = " + somaLinha5);
		diga("soma linha 6 = " + somaLinha6);
		diga("soma linha 7 = " + somaLinha7);

		// se a 0 for maior
		if (somaLinha0 > somaLinha1 && somaLinha0 > somaLinha2 && somaLinha0 > somaLinha3 && somaLinha0 > somaLinha4
				&& somaLinha0 > somaLinha5 && somaLinha0 > somaLinha6 && somaLinha0 > somaLinha7) {
			diga("A linha 0 tem a maior soma, com o valor " + somaLinha0);
		}

		// se 1 for maior
		if (somaLinha1 > somaLinha0 && somaLinha1 > somaLinha2 && somaLinha1 > somaLinha3 && somaLinha1 > somaLinha4
				&& somaLinha1 > somaLinha5 && somaLinha1 > somaLinha6 && somaLinha1 > somaLinha7) {
			diga("A linha 1 tem a maior soma, com o valor " + somaLinha1);
		}

		// se 2 for maior
		if (somaLinha2 > somaLinha0 && somaLinha2 > somaLinha1 && somaLinha2 > somaLinha3 && somaLinha2 > somaLinha4
				&& somaLinha2 > somaLinha5 && somaLinha2 > somaLinha6 && somaLinha2 > somaLinha7) {
			diga("A linha 2 tem a maior soma, com o valor " + somaLinha2);
		}

		// se 3 for maior
		if (somaLinha3 > somaLinha0 && somaLinha3 > somaLinha1 && somaLinha3 > somaLinha2 && somaLinha3 > somaLinha4
				&& somaLinha3 > somaLinha5 && somaLinha3 > somaLinha6 && somaLinha3 > somaLinha7) {
			diga("A linha 3 tem a maior soma, com o valor " + somaLinha3);
		}

		// se 4 for maior
		if (somaLinha4 > somaLinha0 && somaLinha4 > somaLinha1 && somaLinha4 > somaLinha2 && somaLinha4 > somaLinha3
				&& somaLinha4 > somaLinha5 && somaLinha4 > somaLinha6 && somaLinha4 > somaLinha7) {
			diga("A linha 4 tem a maior soma, com o valor " + somaLinha4);
		}

		// se 5 for maior
		if (somaLinha5 > somaLinha0 && somaLinha5 > somaLinha1 && somaLinha5 > somaLinha2 && somaLinha5 > somaLinha3
				&& somaLinha5 > somaLinha4 && somaLinha5 > somaLinha6 && somaLinha5 > somaLinha7) {
			diga("A linha 5 tem a maior soma, com o valor " + somaLinha5);
		}

		// se 6 for maior
		if (somaLinha6 > somaLinha0 && somaLinha6 > somaLinha1 && somaLinha6 > somaLinha6 && somaLinha4 > somaLinha3
				&& somaLinha6 > somaLinha4 && somaLinha6 > somaLinha5 && somaLinha6 > somaLinha7) {
			diga("A linha 6 tem a maior soma, com o valor " + somaLinha6);
		}

		// se 7 for maior
		if (somaLinha7 > somaLinha0 && somaLinha7 > somaLinha1 && somaLinha7 > somaLinha2 && somaLinha7 > somaLinha3
				&& somaLinha7 > somaLinha4 && somaLinha7 > somaLinha5 && somaLinha7 > somaLinha6) {
			diga("A linha 7 tem a maior soma, com o valor " + somaLinha7);
		}

	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex16.xml");

	}

}
