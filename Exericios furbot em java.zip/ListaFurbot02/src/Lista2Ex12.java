import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

public class Lista2Ex12 extends Furbot {
	
	public void inteligencia() throws Exception {
		diga ("nasci em: " + getX() + " ," + getY());
			
		while (ehVazio(DIREITA) && !ehFim(DIREITA)) {
			andarDireita();	
		} 
		diga("Fim do primeiro la�o AQUI!");
		
		if (!ehFim(DIREITA)) {
			if (ehVazio(ABAIXO)) {
					andarAbaixo();
			
				if (ehVazio(DIREITA)  && !ehFim(DIREITA)) {
						andarDireita();
				
					if (ehVazio(DIREITA)  && !ehFim(DIREITA)) {
							andarDireita();
					
						if (ehVazio(ACIMA)) {
								andarAcima();
						
							while (ehVazio(DIREITA) && !ehFim(DIREITA)) {
								andarDireita();	} 
						
							if (ehFim(DIREITA)) {
								diga("N�o posso andar direita!");}
					
						} else {diga("N�o posso andar acima!");}
		
					} else {diga("N�o posso andar o primeiro passo p/ direita!");}	
					
				} else {diga("N�o posso andar o segundo passo p/ direita!");}
			
			} else {diga("N�o posso andar abaixo! Algo me imepede!");}
		} else { diga("N�o posso andar a direita!");}
							/*
						else {diga("N�o posso andar acima!");}
					else {diga("N�o posso andar pela segunda vez a direita!");}
				else {diga("N�o posso andar pela primeira vez vez a direita!");}		
			else {diga("N�o posso andar abaixo!");}	*/
			
		diga ("cheguei em : " + getX() + " ," + getY());
		
	}
	

	
    public ImageIcon buildImage() {      
          return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex12.xml");

	}

}
