
public class JogoDaVelhaV1 {
	
	    private char[][] tabuleiro;//declara um tabuleiro com coordenadas [0..2][0..2]
	    private static final int LINHAS = 3;
	    private static final int COLUNAS = 3;
	    
	    public JogoDaVelhaV1() { //metodo CONSTRUTOR
	       tabuleiro = new char[LINHAS][COLUNAS]; //aloca memoria para o tabuleiro
	       
	       //preenche com espacos
	       for (int i = 0; i < LINHAS;i++) {
	           for (int j = 0; j < COLUNAS; j++) {
	               tabuleiro [i][j] = '.';
	           } //for j
	       }//for i
	       
	       //na saida deste metodo construtor temos um tabuleiro criado
	    }
	    

	    
	    public static void main(String args[]) {
	        JogoDaVelhaV1 jv = new JogoDaVelhaV1(); //cria um objeto JogoDaVelhaV1
	        System.out.println(jv);
	    }
	    
	}
