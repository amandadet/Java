import javax.swing.JOptionPane;

public class JogoDaVelhaV4 {
        private char[][] tabuleiro;
    private static final int LINHAS = 3;
    private static final int COLUNAS = 3;
    
    public JogoDaVelhaV4() {
       tabuleiro = new char[LINHAS][COLUNAS]; //cria um tabuleiro com coordenadas [0..2][0..2]
       
       //preenche com "."para demonstrar espaço vazio
       for (int i = 0; i < LINHAS;i++) { //varre cada linha
           for (int j = 0; j < COLUNAS; j++) { //varre cada coluna da linha
               tabuleiro [i][j] = '.';
           }//for j
       }//for i
    }

    
    public void mostraTabuleiroComoCoordenadas() {
    	System.out.println("Coordenadas do tabuleiro");
        for (int i = 0; i<LINHAS;i++) { //varre cada linha
            System.out.print('|');            //inicia a linha com um marcador de barra
            for (int j = 0; j< COLUNAS; j++) { //varre cada coluna
                System.out.print("("+i+","+j+")");   //concatena seu conteúdo
            }//for j
            System.out.println('|');   //apos encerrar a varredura das colunas, concatena uma barra final
        } //for i
    }
    
    public void mostraConteudoDoTabuleiro () {
    	System.out.println("CONTE�DO do tabuleiro");
    	System.out.println(this.toString());
    }
    
    /*
     * Método registraJogada recebe uma coordenada x e uma coordenada Y e a identificacao do jogador
     * Este metodo verifica se a posicao indicada está vazia (marcada com um ".") e se estiver, registra a
     * jogada do jogador.
     */
    public boolean registraJogada(int x,int y,char jogador) {
        if (tabuleiro[x][y] != '.') {
            System.out.println("A posicao esta ocupada, escolha outra");
            return false;
        } else {
            tabuleiro[x][y] = jogador; //registra a jogada do jogador
        }
        return true;
    }
    /*
     * toString é um metodo padrao utilizado para fazer com que a classe "mostre-se" de alguma forma.
     * Neste caso, o método formata um String registrando o estado do tabuleiro após a jogada
     */
    public String toString() {
        String lin = "";
        for (int i = 0; i<LINHAS;i++) { //varre cada linha
            lin = lin + '|';            //inicia a linha com um marcador de barra
            for (int j = 0; j< COLUNAS; j++) { //varre cada coluna
                lin = lin + tabuleiro[i][j];   //concatena seu conteúdo
            }//for j
            lin = lin + '|' + "\n";   //apos encerrar a varredura das colunas, concatena uma barra final
        } //for i
        return lin; //retorna um string contendo o estado do tabuleiro formatado
    }
    
    public static void main(String args[]) {
        //declaracao das variaveis
    	 boolean repetir = true;
         char jogador = 'x'; // determina que o jogador "x"inicia jogando
         
    	JogoDaVelhaV4 jogodavelha = new JogoDaVelhaV4();  //cria um OBJETO JogoDaVelhaV4
    	jogodavelha.mostraTabuleiroComoCoordenadas();   //envia uma MENSAGEM para o OBJETO
        
        while (repetir) {
        	jogodavelha.mostraConteudoDoTabuleiro();			//envia outra MENSAGEM para o OBJETO
           
           String jogada = JOptionPane.showInputDialog("Informe a coordenada de LINHA para o jogador ["+jogador+ "] (Cancele para sair)");
           if (jogada == null) { //significa que nao foi informado um valor valido
               repetir = false;
           } else {
               int linha = Integer.parseInt(jogada);
               jogada = JOptionPane.showInputDialog("Informe a coordenada de COLUNA para o jogador ["+jogador+ "] (Cancele para sair)");
               int coluna = Integer.parseInt(jogada);
               
               if (jogodavelha.registraJogada(linha,coluna,jogador) == true) { //se a jogada foi valida
            	   //decide qual é o proximo jogador
                  if (jogador == 'x')  { 
                      jogador = 'o';
                  }  else {
                      jogador = 'x';
                  }
               }
           }        
        }//volta a repetir 
        System.out.println("FIM");
    }
}
