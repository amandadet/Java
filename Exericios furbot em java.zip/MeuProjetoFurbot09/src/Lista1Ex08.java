import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

// o nome da classe deve ser igual ao nome do arquivo 

public class Lista1Ex08 extends Furbot {
	
	public void inteligencia() throws Exception {
		diga ("mundo de furbot");
		andarEsquerda();
		andarEsquerda();
		andarEsquerda();
		andarEsquerda();
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		andarDireita();
		andarDireita();
		andarDireita();
		andarDireita();
		andarAcima();
		andarDireita();
		andarAcima();
		andarAcima();
		diga("Cheguei no tesouro!");
	}
	
    public ImageIcon buildImage() {      
          return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista1Ex08.xml");

	}

}


