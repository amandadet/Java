import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Booleano;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista5Ex03 extends Furbot {
	int numero = 0;
	int valor = 0;
	String numeroBinario;
	String numBin;
	boolean repetir = true;
	public static final int MAX_LIN = 8;
	int[] matriz_numerica = new int[MAX_LIN];

	void montaMatrizNumerica() {
			if (ehObjetoDoMundoTipo("Booleano", AQUIMESMO)) {
				Booleano bool = getObjeto(AQUIMESMO);			
				if (bool.getValor()==true) {
					numeroBinario = numeroBinario + "1";
				} else {
					if(bool.getValor()==false) {
						numeroBinario = numeroBinario + "0";						
					}
				}
				
			}
		}
	
	
		// tenho que montar uma subtring que come�e em 0 e va ateh o len
	    void binarioParaDecimal() {
			numBin = numeroBinario.substring(4, numeroBinario.length());
			diga(numBin);  	
	    	int valorPosicao= 0;
	    	char letraPosicaoStr;
		    int valorDecimal = 0;
	        for (int i = 7; i >= 0; i--) {
	            letraPosicaoStr = numBin.charAt(i);
	            if(letraPosicaoStr == '1') {
	                valorDecimal += Math.pow(2, (valorPosicao));
	            }
	            valorPosicao++;
	        }
	        
	        diga(valorDecimal);
	    }
	    
		//int numeroBinarioFinal = Integer.parseInt(numBin, 2);
		//diga(numeroBinarioFinal);
	
	


	public void inteligencia() throws Exception {
		diga("Exerc�cio 03 - Lista 05");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				montaMatrizNumerica();
				andarDireita();
			} // while
			if (!ehFim(ABAIXO)) {// se nao eh fim abaixo, executa o bloco
				montaMatrizNumerica();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					montaMatrizNumerica();
					andarEsquerda();
				} // while
				if (!ehFim(ABAIXO)) {
					montaMatrizNumerica();
					andarAbaixo();
				} else {
					repetir = false;// encerra o laco de repeticao
				}
			} else {
				repetir = false; // encerra o laco de repeticao
			}
		} // while

		diga("Numero em binario ");
		binarioParaDecimal();
		
	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista5Ex03.xml");

	}

}