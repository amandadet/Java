import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista5Ex05 extends Furbot {
	
	Numero personagemNumero = new Numero();
	boolean repetir = true;
	public static final int MAX_NUM = 20;
	int[] matriz_numerica = new int[MAX_NUM];
	int quantidadeRealDeNumeros = 0;
	int totalSomaDeNumeros = 0;
	
	void percorreMatriz() {
		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO)==true) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem0 = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem0);
			matriz_numerica[quantidadeRealDeNumeros]=valor;	
			quantidadeRealDeNumeros++;
			totalSomaDeNumeros = totalSomaDeNumeros + valor;
		}
	}
	
	public void inteligencia() throws Exception {
		diga("Exerc�cio 04 - Lista 05");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				percorreMatriz();
				andarDireita();
			} 
			if (!ehFim(ABAIXO)) {
				percorreMatriz();
				andarAbaixo();
				while (!ehFim(ESQUERDA)) {	
					percorreMatriz();
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {	
					percorreMatriz();
					andarAbaixo();
				} else {
					repetir = false;
				}
			} else {
				repetir = false; 
			}
		} 
		float media = totalSomaDeNumeros/quantidadeRealDeNumeros;
		diga("A quantidade de numeros encontrados �: "+quantidadeRealDeNumeros);
		diga(" ");
		diga("M�dia: " + media);
		diga(" ");
		for (int i=0; i<MAX_NUM;i++) {
			if (matriz_numerica[i]>media) {
				diga("O n�mero " + matriz_numerica[i] + " � maior que a m�dia.");
			}
		}
		
		
	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista5Ex05.xml");

	}

}