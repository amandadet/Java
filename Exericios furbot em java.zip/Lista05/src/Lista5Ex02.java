import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.ObjetoDoMundo;
import br.furb.furbot.suporte.LoadImage;

public class Lista5Ex02 extends Furbot {

	Numero personagemNumero = new Numero();
	int soma = 0;
	boolean repetir = true;
	public static final int MAX_LIN = 8;
	public static final int MAX_COL = 8;
	int [][] matriz_numerica = new int[MAX_LIN][MAX_COL];
	float [][] matriz_final = new float[MAX_LIN][MAX_COL];

	void montaMatrizNumerica() {
		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem0 = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem0);
			matriz_numerica[getX()][getY()] = valor;
		}
	}

	void manipulaMatriz() {
		for (int linha = 0; linha < MAX_LIN; linha++) {
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				if (matriz_numerica[linha][coluna] != 0) {
					if (coluna % 2 == 0) {
						double temporario = matriz_numerica[linha][coluna];
						temporario = temporario+ temporario * 0.10;
						float f = (float)temporario;
						matriz_final[linha][coluna]=f;
					} else {
						if (coluna % 2 != 0) {
							double temporario = matriz_numerica[linha][coluna];
							temporario = temporario - temporario * 0.10;
							float f = (float)temporario;
							matriz_final[linha][coluna]=f;
						}
					}

				}
			}
		}
	}

	// esse seria o metodo para realizar a inser��o dos objetos no tabuleiro
	// tivemos dificuldade em fazer com que ele funcionasse, por este motivo 
	// colocamos os valores dos numeros apos acrescrescentar ou drecementar 10 por cento
	// em uma outra lista e mostramos no console
	void reinsereNumerosNoTabuleiro() {
		for (int linha = 0; linha < MAX_LIN; linha++) {
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				if (!ehVazio(AQUIMESMO)) {
				
					// nessa etapa do code da um erro dizendo que jah existe um objeto do mundo nessa posicao
					// mesmo depois de remover o numero que esta ocupando o lugar dele
					
					//removo o objeto que existe nessa posicao
					ObjetoDoMundo temporario = new Numero();
					temporario = getObjeto(AQUIMESMO);
					removerObjetoDoMundo(temporario); 
					
					//coloco o novo objeto
					int num = matriz_numerica[linha][coluna];
					Numero numeroManipulado = new Numero();
					numeroManipulado.setValor(num);
					adicionarObjetoNoMundo(personagemNumero, AQUIMESMO);
				}
			}
		}
	}

	public void inteligencia() throws Exception {
		diga("Exerc�cio 02 - Lista 05");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				montaMatrizNumerica();
				andarDireita();
			} // while
			if (!ehFim(ABAIXO)) {// se nao eh fim abaixo, executa o bloco
				montaMatrizNumerica();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					montaMatrizNumerica();
					andarEsquerda();
				} // while
				if (!ehFim(ABAIXO)) {
					montaMatrizNumerica();
					andarAbaixo();
				} else {
					repetir = false;// encerra o laco de repeticao
				}
			} else {
				repetir = false; // encerra o laco de repeticao
			}
		} // while

		// mostro a primeira matriz
		for (int i = 0; i < MAX_LIN; i++) {
			for (int j = 0; j < MAX_COL; j++) {
				System.out.print(matriz_numerica[j][i] + ",");
			}
		}

		// mostro a matriz depois de acrescentar ou decrementar 10 por cento do valor do
		// numero
		manipulaMatriz();
		System.out.println(" ");
		for (int i = 0; i < MAX_LIN; i++) {
			for (int j = 0; j < MAX_COL; j++) {
				System.out.print(matriz_final[j][i] + ",");
			}
		}
		
		
		//volto para o inicio pois o furbot vai ter que passar pelo tabuleiro de novo setando os novos valores

		while(!ehFim(ESQUERDA)) {
			andarEsquerda();
		}
		while(!ehFim(ACIMA)) {
			andarAcima();
		}
		
		

	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista5Ex02.xml");

	}

}