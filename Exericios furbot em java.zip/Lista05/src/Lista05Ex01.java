import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista05Ex01 extends Furbot {

	Numero personagemNumero = new Numero();
	int numero;
	int soma = 0;
	boolean repetir = true;
	public static final int MAX_LIN = 8;
	public static final int MAX_COL = 8;
	int[][] matriz_numerica = new int[MAX_LIN][MAX_COL];
	int[][] ordemInversa = new int[MAX_LIN][MAX_COL];

	void montaMatrizNumerica() {
		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem0 = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem0);
			matriz_numerica[getX()][getY()] = valor;
		}
	}

	void inverteOrdem() {
		for (int linha = MAX_LIN-1; linha >= 0; linha--) {
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				numero = matriz_numerica[coluna][linha];
				diga(numero);			
				}
			}
		}
	

	public void inteligencia() throws Exception {
		diga("Exerc�cio 01 - Lista 05");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				montaMatrizNumerica();
				andarDireita();
			} // while
			if (!ehFim(ABAIXO)) {// se nao eh fim abaixo, executa o bloco
				montaMatrizNumerica();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					montaMatrizNumerica();
					andarEsquerda();
				} // while
				if (!ehFim(ABAIXO)) {
					montaMatrizNumerica();
					andarAbaixo();
				} else {
					montaMatrizNumerica();
					repetir = false;// encerra o laco de repeticao
				}
			} else {
				montaMatrizNumerica();
				repetir = false; // encerra o laco de repeticao
			}
		} // while
		diga("fim do zigue-zague horizontal");
		diga("ordem inversa: ");
		inverteOrdem();
	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista05Ex01.xml");

	}

}