
public class q2 {
	public static void main(String[] args) throws Exception {
	
		System.out.println("Quest�o 2 da Amanda Detofol Constante");
		
		// declare uma variavel do tipo inteiro e atribua o valor maximo permitido
		int inteiro =(Integer.MAX_VALUE);
		
		//declare outra variavel do tipo inteiro com o valor 
		int inteiro2 = 0;
		
		// declare uma variavel do tipo float
		float flutuante;
		
		//atribua a segunda variavel pelo valor da primeira variavel multiplicado por 2
		inteiro2 = inteiro*2;
		
		//atribua a terceira variavel pelo valor da segunda variavel multiplicado por 10
		flutuante =  inteiro2*10;
		
		// atribua a  segunda variavel  o valor da terceira variavel
		inteiro2 = (int)flutuante;
		
		System.out.println(inteiro);
		System.out.println(inteiro2);
		System.out.println(flutuante);
		System.out.println(inteiro2);
		
	}
}
