import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class q3 {
	public static void main(String[] args) throws Exception {

		System.out.println("Quest�o 3 da Amanda Detofol Constante");

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Quest�o 3");
		System.out.println("Informe um numero: ");

		// o primeiro erro � logo abaixo quando � declarada uma variavel tipo int para
		// receber dados do teclado
		// basta mudar o tipo da variavel para String
		String respostaDigitada = in.readLine();

		// o segundo erro estava abaixo abaixo, onde estava declarado Integer.parseFloat
		// o tipo da variavel � inteira, logo n�o suporta o float, e tamb�m a convers�o
		// para float
		// � feita de forma divergente
		// para corrigir basta modificar para parseInt
		int valorConvertido = Integer.parseInt(respostaDigitada);

		Random varAleatoria = new Random();

		// para realizar a opera��o � preciso atribuir um valor aleat�rio a uma variavel
		// primeiro
		// pois se multiplicarmos a variavel varAleat�ria, estamos multiplicando uma
		// vari�vel que cont�m uma classe
		// e n�o um valor numerico
		int valorAleatorio = varAleatoria.nextInt();
		
		float valor2 = valorAleatorio * valorConvertido;

		System.out.println("Digitei o valor " + valorConvertido + " e o resultado foi: ");
		if (valor2 < 10) {
			// aqui n�o tem o ("+valor2+")
			// a intui��o � mostrar o valor da variavel logo o certo �
			// + valor2
			System.out.println("O valor final � menor do que 10: " + valor2);
		} else {
			if (valor2 > 100) {
				// aqui n�o tem o ("+valor2+")
				// a intui��o � mostrar o valor da variavel logo o certo �
				// + valor2
				System.out.println("O valor final � menor do que 10 e maior do que 100: " + valor2);
			} else {
				// aqui n�o tem o ("+valor2+")
				// a intui��o � mostrar o valor da variavel logo o certo �
				// + valor2
				System.out.println("O valor final � maior do que 100: " + valor2);
			}
		}

	}
}
