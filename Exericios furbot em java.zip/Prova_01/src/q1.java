
public class q1 {
	public static void main(String[] args) {

		System.out.println("Questao 01 da Amanda Detofol Constante");

		String message = "I hope this works";
		String part1 = message.substring(0, 2);
		String part2 = message.substring(message.length() - 2);
		System.out.println(part1 + part2);
		// System.out.println(part1 * part2);

	}// end main method

}// end class
