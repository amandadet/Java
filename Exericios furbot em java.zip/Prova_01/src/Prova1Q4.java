import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Prova1Q4 extends Furbot {

	public void inteligencia() throws Exception {
		System.out.println("Questao 4 da Amanda Detofol Constante");
		diga("mundo de furbot");

		boolean repetir;
		repetir = true;
		Numero personagemNumero = new Numero();
		int contadorNumerosPares = 0;
		int valorNumerosImpares = 0;
		int contadorNumerosImpares = 0;
		int totalNumeros = 0;

		limparConsole();
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				if (!ehVazio(DIREITA)) {
					// pego o valor a direita
					personagemNumero = getObjeto(DIREITA);
					String valorDoPersonagem0 = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem0);

					// se for par adiciono apenas +1 na variavel
					if (valor % 2 == 0) {
						contadorNumerosPares = contadorNumerosPares + 1;
						// se n�o for par, ele s� pode ser impar
						// adiciono o valor do numero na variavel
						// somo +1 no contador de impares
					} else {
						valorNumerosImpares = valorNumerosImpares + valor;
						contadorNumerosImpares = contadorNumerosImpares + 1;
					}

				}

				andarDireita();
			} // while
			if (!ehFim(ABAIXO)) {
				andarAbaixo();
				if (!ehVazio(AQUIMESMO)) {
					// pego o valor aquimesmo
					personagemNumero = getObjeto(AQUIMESMO);
					String valorDoPersonagem0 = personagemNumero.toString();
					int valor = Integer.parseInt(valorDoPersonagem0);

					// se for par adiciono apenas +1 na variavel
					if (valor % 2 == 0) {
						contadorNumerosPares = contadorNumerosPares + 1;
						// se n�o for par, ele s� pode ser impar
						// adiciono o valor do numero na variavel
						// somo +1 no contador de impares
					} else {
						valorNumerosImpares = valorNumerosImpares + valor;
						contadorNumerosImpares = contadorNumerosImpares + 1;
					}

				}

				while (!ehFim(ESQUERDA)) {
					if (!ehVazio(ESQUERDA)) {
						// pego o valor a esquerda
						personagemNumero = getObjeto(ESQUERDA);
						String valorDoPersonagem0 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem0);

						// se for par adiciono apenas +1 na variavel
						if (valor % 2 == 0) {
							contadorNumerosPares = contadorNumerosPares + 1;
							// se n�o for par, ele s� pode ser impar
							// adiciono o valor do numero na variavel
							// somo +1 no contador de impares
						} else {
							valorNumerosImpares = valorNumerosImpares + valor;
							contadorNumerosImpares = contadorNumerosImpares + 1;
						}

					}

					andarEsquerda();
				} // while
				if (!ehFim(ABAIXO)) {
					andarAbaixo();
					if (!ehVazio(AQUIMESMO)) {
						// pego o valor aquimesmo
						personagemNumero = getObjeto(AQUIMESMO);
						String valorDoPersonagem0 = personagemNumero.toString();
						int valor = Integer.parseInt(valorDoPersonagem0);

						// se for par adiciono apenas +1 na variavel
						if (valor % 2 == 0) {
							contadorNumerosPares = contadorNumerosPares + 1;
							// se n�o for par, ele s� pode ser impar
							// adiciono o valor do numero na variavel
							// somo +1 no contador de impares
						} else {
							valorNumerosImpares = valorNumerosImpares + valor;
							contadorNumerosImpares = contadorNumerosImpares + 1;
						}

					}

				} else {
					repetir = false;
				}
			} else {
				repetir = false;
			}
		}

		totalNumeros = contadorNumerosImpares + contadorNumerosPares;
		diga("Encontrei " + totalNumeros + " n�meros, destes " + contadorNumerosPares + " eram pares e a soma dos �mpares foi " + valorNumerosImpares);
		diga("fim do zigue-zague horizontal");
		diga("fim da questao 3");
	
	
		
	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Prova1Q4.xml");

	}

}
