import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

// o nome da classe deve ser igual ao nome do arquivo 

public class Lista1Ex04 extends Furbot {
	
	public void inteligencia() throws Exception {
		diga ("mundo de furbot");
		andarDireita();
		andarDireita();
		andarDireita();
		diga("Cheguei no extremo direita!");
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		diga("Cheguei no extremo abaixo!");
		andarEsquerda();
		andarEsquerda();
		andarEsquerda();
		diga("Cheguei no extremo esquerda!");
		andarAcima();
		andarAcima();
		andarAcima();
		diga("Voltei para o come�o!");
	}
	
    public ImageIcon buildImage() {      
          return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista1Ex04.xml");

	}

}


