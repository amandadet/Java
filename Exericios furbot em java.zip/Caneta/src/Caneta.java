
public class Caneta {
	// defini��o das variaveis de caneta
	// um atributo possui um tipo e um nome, n�o � necess�rio ter um valor dafault
	
	String cor = "amarelo";
	byte espessuraDaPonta = 1;
	byte comprimento = 1;
	double largura = 1.5;

	
	// defini��o de comportamentos
	// comportamentos =  m�todos
	public void escrever() {
		double duracaoTinta = 0;	
		duracaoTinta = comprimento * largura * 360;
		System.out.println("O valor da dura��o �: " + duracaoTinta);		
	}
	
	public static void main(String[] args) {
		Caneta caneta = new Caneta();
		caneta.escrever();

	}

}
