import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista3Q1 extends Furbot {
	
	int linhaComMaiorSoma = 0;
	int numLinhaComMaiorSoma = 0;
	int somaDaLinha = 0;
	int somaTotal = 0;
	
	public void verificaMaiorSomaDaLinha (Direcao direcao) {
		Numero personagemNumero = new Numero();
		if (!ehVazio(direcao)) {
			personagemNumero = getObjeto(direcao);
			String valorDoPersonagem = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem);
			somaDaLinha = somaDaLinha + valor;
			somaTotal = somaTotal + valor;

		}		
	}
	
	public void inteligencia() throws Exception {
				
		boolean repetir;		
		repetir = true; 

		while (repetir == true) {
			somaDaLinha=0;
			while (!ehFim (DIREITA)) {
				verificaMaiorSomaDaLinha (DIREITA);	
				andarDireita();
			}
			if (somaDaLinha>linhaComMaiorSoma) {
				linhaComMaiorSoma = somaDaLinha;
				numLinhaComMaiorSoma = getY();
			}
			
			
			if (!ehFim(ABAIXO)) {
				somaDaLinha=0;
				verificaMaiorSomaDaLinha (ABAIXO);
				andarAbaixo();
				while (!ehFim(ESQUERDA) ) {
					verificaMaiorSomaDaLinha (ESQUERDA);
					andarEsquerda();					
				}//while
				if (somaDaLinha>linhaComMaiorSoma) {
					linhaComMaiorSoma = somaDaLinha;
					numLinhaComMaiorSoma = getY();
				}
				if (!ehFim(ABAIXO)) {
					somaDaLinha=0;
					verificaMaiorSomaDaLinha (ABAIXO);
					andarAbaixo();
				}
				else {
				  repetir = false;//fecha while
				}
			}
			else {
				repetir = false; //fecha while
			}
		}//while	
		this.limparConsole();
		diga ("fim do zigue-zague horizontal");
		diga ("A linha com maior soma foi a linha:" + numLinhaComMaiorSoma);
		diga ("A soma dessa linha foi:" + linhaComMaiorSoma);
		diga ("Soma de todos os n�meros:" + somaTotal);
	}
	
	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista3Q1.xml");

	}

}
