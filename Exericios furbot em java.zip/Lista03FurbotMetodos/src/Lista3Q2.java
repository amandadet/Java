import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista3Q2 extends Furbot {

	// acumulador inicializado em 0
	int acumulador = 0;
	Numero personagemNumero = new Numero();
	String textoDoPersonagem;
	int valorDoPersonagem;

	public void controlaNumero(Direcao direcao) {

		if (ehObjetoDoMundoTipo("Numero", direcao) == true) {
			//pego o valor do n�mero
			personagemNumero = getObjeto(direcao);
			textoDoPersonagem = personagemNumero.toString();
			valorDoPersonagem = Integer.parseInt(textoDoPersonagem);

			// Quando o rob� encontra um n�mero, ele deve diminuir do acumulador esse
			// valor. Por�m, se o acumulador for menor ou igual a zero, ent�o o
			// acumulador recebe o valor do n�mero que encontrou.

			if (acumulador <= 0) {
				acumulador += valorDoPersonagem;
			} else {
				acumulador -= valorDoPersonagem;
			}
	
		}
	}
	
	// quando ele encontra um alien, dobra o valor do acumulador
	public void verificarAlien (Direcao direcao) {
		if (ehObjetoDoMundoTipo("Alien", direcao) == true) {
			acumulador = acumulador*2;
		}
		// acompanhando o valor do acumulador para depurar
		diga("O valor do acumulador �: " + acumulador);
	}

	public void inteligencia() throws Exception {

		boolean repetir;
		repetir = true;

		while (repetir == true) {			
			while (!ehFim(DIREITA)) {
				controlaNumero(DIREITA);
				verificarAlien(DIREITA);
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				controlaNumero(ABAIXO);
				verificarAlien(ABAIXO);
				andarAbaixo();
				while (!ehFim(ESQUERDA)) {
					controlaNumero(ESQUERDA);
					verificarAlien(ESQUERDA);
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					controlaNumero(ABAIXO);
					verificarAlien(ESQUERDA);
					andarAbaixo();
				} else {
					repetir = false;
				}
			} else {
				repetir = false;
			}
		} 
		diga("fim do zigue-zague horizontal");
		diga("O valor FINAL do acumulador �: " + acumulador);

	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista3Q2.xml");

	}
}
