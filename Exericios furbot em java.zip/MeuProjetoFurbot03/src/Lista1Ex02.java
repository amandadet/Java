import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

// o nome da classe deve ser igual ao nome do arquivo ok

public class Lista1Ex02 extends Furbot {
	
	public void inteligencia() throws Exception {
		diga ("mundo de furbot");
		andarAbaixo();
		andarAbaixo();
		andarAbaixo();
		diga("Cheguei!");
	}
	
    public ImageIcon buildImage() {      
          return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista1Ex02.xml");

	}

}



