import javax.swing.ImageIcon;
import java.util.Scanner;
import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class ListaxEx01 extends Furbot {

	Numero personagemNumero = new Numero();
	int somaNumeros = 0;
	int qtdNumeros = 0;
	String seqNumero = " ";
	int len = 0;

	public void manipulaNumeros(Direcao direcao) {
		if (!ehVazio(direcao)) {
			personagemNumero = getObjeto(direcao);
			String valorDoPersonagem = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem);
			qtdNumeros++;
			somaNumeros = somaNumeros + valor;
			seqNumero = seqNumero + " - " + valorDoPersonagem;
			len = seqNumero.length();

		}
	}

	public void inteligencia() throws Exception {

		boolean repetir;
		repetir = true;

		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				manipulaNumeros(DIREITA);
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				manipulaNumeros(ABAIXO);
				andarAbaixo();
				while (!ehFim(ESQUERDA)) {
					manipulaNumeros(ESQUERDA);
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					manipulaNumeros(ABAIXO);
					andarAbaixo();
				} else {
					repetir = false;
				}
			} else {
				repetir = false;
			}
		}

		this.limparConsole();
		diga("A quantidade de numeros encontrados foi:" + qtdNumeros);
		diga("A media dos numeros encontrados foi:" + (somaNumeros / qtdNumeros));
		
		if (somaNumeros>50){
			diga("A raiz quadrada do somatorio foi: " + (Math.sqrt(somaNumeros)));
		} else {
			diga("S� devo calcular a raiz se a soma dos n�meros for maior do que 50");
		}
		
		diga("A sequencia dos numeros foi:");
		diga(seqNumero.substring(3, len));

	}

	public ImageIcon buildImage() {
		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("ListaxEx01.xml");

	}

}
