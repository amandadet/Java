import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Prova02Ex01 extends Furbot {

	//Equipe01
	// Amanda Detofol
	// Felipe
	//Iago
	//Stephani
	
	int tijolosParede = 0;		
	boolean controlador = false;

	public void contaTijolos() {
		
		while (ehVazio(ACIMA)) {
			
			// |
			while (!ehVazio(DIREITA)) {
				tijolosParede = tijolosParede+1;
				andarAcima();
			}
			
			
			if (!ehVazio(AQUIMESMO)) {
				andarDireita();
				andarDireita();
				andarAbaixo();

			}
			while (!ehVazio(ESQUERDA)) {
				
				
				//vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as parede
				if (!ehFim(ABAIXO)) {
					andarAbaixo();
				} else {
					diga("N�o posso continuar o passeio.");
					diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
					break;
				}
			}
			if(!ehFim(ABAIXO)) {
			andarEsquerda();
			andarEsquerda();
			andarAcima();
			controlador = true;
			break;
			}
		}

		if (controlador == false) {
			while (!ehVazio(ACIMA)) {
				if (ehVazio(ESQUERDA)) {
					// ---| ou --| atende a duas config de mundo
					while (!ehVazio(ACIMA)) {
						tijolosParede = tijolosParede+1;
						andarEsquerda();
					}

					andarAcima();
					andarAcima();
					andarDireita();
					andarDireita();

					
					if (!ehVazio(AQUIMESMO)) {
						andarDireita();
					}

					while (!ehVazio(ABAIXO)) {
						tijolosParede = tijolosParede+1;
						andarDireita();
					}

					
					// vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
					if (!ehFim(ABAIXO)) {
						andarAbaixo();
					} else {
						diga("N�o posso continuar o passeio.");
						diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
						break;
					}
					
					while (!ehVazio(ESQUERDA)) {
						
						andarAbaixo();
						tijolosParede = tijolosParede+1;
					
						// vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
						if (!ehFim(ABAIXO)) {
							andarAbaixo();
						} else {
							diga("N�o posso continuar o passeio.");
							diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
							break;
						}
					}
					if(!ehFim(ABAIXO)) {
					andarEsquerda();
					andarEsquerda();
					andarAcima();
					}
				} else {
					
					// |-- essa config de mundo
					while (!ehVazio(ACIMA)) {
						tijolosParede = tijolosParede+1;
						andarDireita();
					}		
					andarAcima();
					andarAcima();
					andarEsquerda();
					andarEsquerda();
					andarEsquerda();
					
					
					while (!ehVazio(ABAIXO)) {
						tijolosParede = tijolosParede+1;
						andarEsquerda();
					}
					andarAbaixo();
					andarAbaixo();
					
					
					if (!ehVazio(DIREITA))
						tijolosParede = tijolosParede+1;
					//vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
					if (!ehFim(ABAIXO)) {
						andarAbaixo();
					} else {
						diga("N�o posso continuar o passeio.");
						diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
						break;
					}
					andarDireita();
					andarDireita();
					andarAcima();
				}
				break;
			}
		}

		diga("A parede era composta por " + tijolosParede + " tijolos.");
	}

	public void inteligencia() {

		limparConsole();
		tijolosParede = 0;
		contaTijolos();
		
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Prova02Ex01.xml");

	}

}