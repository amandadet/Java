import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista4Ex01 extends Furbot {

	Numero personagemNumero = new Numero();
	int menorNumero = 0;
	int maiorNumero = 0;
	int valor = 0;
	
	public void voltarInicio() {
		while (!ehFim(ESQUERDA)) {		
			andarEsquerda();
		}
		while(!ehFim(ACIMA)) {
			andarAcima();
		}
	}
	
	public void manipulaNumeros(Direcao direcao) {
		if (!ehVazio(direcao)) {
			personagemNumero = getObjeto(direcao);
			String valorDoPersonagem = personagemNumero.toString();
			valor = Integer.parseInt(valorDoPersonagem);
			
			if (menorNumero == 0) {
				menorNumero = valor;
			}
			
			if (valor>maiorNumero) {
				maiorNumero=valor;
			} else {
				if(valor<menorNumero) {
					menorNumero = valor;
				}
			}
		}
	}
	
	public void inteligencia() throws Exception {
		
		// volto para o 0,0 para fazer o passeio pelo mundo
		voltarInicio();
		
		boolean repetir;
		repetir = true;
		menorNumero=valor;
		
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				manipulaNumeros(DIREITA);	
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				manipulaNumeros(ABAIXO);
				andarAbaixo();
				while (!ehFim(ESQUERDA)) {
					manipulaNumeros(ESQUERDA);
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					manipulaNumeros(ABAIXO);
					andarAbaixo();
				} else {
					repetir = false;}
				
			} else {
				repetir = false;
			}
		}
	
		this.limparConsole();
		diga("O menor numero foi " + menorNumero + " e o maior numero foi " + maiorNumero);
		
		for(int i = menorNumero; i <= maiorNumero; ++i){
			diga(i);
		}

	}

	public ImageIcon buildImage() {
		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista4Ex01.xml");

	}

}
