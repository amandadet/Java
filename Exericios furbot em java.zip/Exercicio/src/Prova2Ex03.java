import javax.swing.ImageIcon;

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Prova2Ex03 extends Furbot {
	
	boolean loopInicial = true;
	boolean loop = true;
	boolean loopRetorno = false;
	public String ultimaDirecao;
	boolean paredeACIMA = false;
	boolean paredeDIREITA = false;
	boolean paredeABAIXO = false;
	boolean paredeESQUERDA = false;
	int posX;
	int posY;
	
	public void mapeiaParedes() {
	//Mapeia as paredes ao redor do furbot 
			
	if(ehObjetoDoMundoTipo("Parede",ACIMA) || ehFim(ACIMA)){
		paredeACIMA = true;
	} else {
		paredeACIMA = false;
	}
	if(ehObjetoDoMundoTipo("Parede",DIREITA) || ehFim(DIREITA)) {
		paredeDIREITA = true;
	} else {
		paredeDIREITA = false;
	}
	if(ehObjetoDoMundoTipo("Parede",ABAIXO) || ehFim(ABAIXO)){
		paredeABAIXO = true;
	} else {
		paredeABAIXO = false;
	}
	if(ehObjetoDoMundoTipo("Parede",ESQUERDA) || ehFim(ESQUERDA)) {
		paredeESQUERDA = true;
	} else {
		paredeESQUERDA = false;
	}
	
	}

	public void verificaObjetivo() {
		mapeiaParedes();
		posX = getX();
		posY = getY();
		if(posX == 0 && posY == 0) {
			diga("cheguei no objetivo");
			loopInicial = false;
			loop = false;
		} else if (posX == 0 && posY == 1 && paredeACIMA == true) {
			diga("Existe uma parede na posicao de destino, nao consigo prosseguir");
			loopInicial = false;
			loop = false;
		} else if (posX == 1 && posY == 0 && paredeESQUERDA == true) {
			diga("Existe uma parede na posicao de destino, nao consigo prosseguir");
			loopInicial = false;
			loop = false;
		} else if (posX == 1 && posY == 1 && paredeACIMA == true && paredeESQUERDA == true) {
			diga("Existem paredes a esquerda e acima, nao consigo chegar ao destino");
			loopInicial = false;
			loop = false;
		}
	}
	
	public void ifBecoAcima() {
		if(paredeACIMA == true && paredeESQUERDA == true && paredeABAIXO == false) {
			loopRetorno = true;
			while(loopRetorno == true) {
				andarAbaixo();
				mapeiaParedes();
				if(paredeESQUERDA == false) {
					loopRetorno = false;
					andarEsquerda();
				}
			}
		}
	}
	
	public void inteligencia() throws Exception {
		this.limparConsole();
		
		while(loopInicial ==true) {
			mapeiaParedes();
			ifBecoAcima();
			mapeiaParedes();
			if(paredeACIMA == false) {
				andarAcima();
			} else if (paredeESQUERDA == false) {
				andarEsquerda();
			}
			verificaObjetivo();
		}
		diga("fim do codigo");
		

		
	}

public static void main(String[] args) {
	MundoVisual.iniciar("Prova2Ex03.xml");
}

}