import javax.swing.ImageIcon;

 

import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.suporte.LoadImage;

 

public class Prova02ex2 extends Furbot {

 

    public void inteligencia() throws Exception {
        
        int parede1 = 0;
        int parede2 = 0;
        int parede3 = 0;
        int totalDeTijolos = 0;
        float media = 0;
        
            while (!ehFim(DIREITA)) {
                if (ehObjetoDoMundoTipo("Parede", ABAIXO)) {
                
                    parede1 = parede1 + 1;        
                }
                andarDireita();
            }    
            if (ehFim(DIREITA)) {
                andarAbaixo();
                andarAbaixo();
            }                
                while (!ehFim(ESQUERDA)) {                
                    andarEsquerda();
                }
                while (!ehFim(DIREITA)) {
                    if (ehObjetoDoMundoTipo("Parede", ABAIXO)) {                        
                        parede2 = parede2 + 1;                                
                    }                    
                    andarDireita();
                }
                                
                if (ehFim(DIREITA)) {
                    andarAbaixo();
                    andarAbaixo();
                }
                while (!ehFim(ESQUERDA)) {                                    
                    andarEsquerda();
                }
                while (!ehFim(DIREITA)) {
                    if (ehObjetoDoMundoTipo("Parede", ABAIXO)) {
                            
                        parede3 = parede3 + 1;                                                    
                    }                    
                    andarDireita();
                }        
                
                if((parede1 > parede2) && (parede1 > parede3)) {
                    diga(" A arede 01 tem mais tijolos");
                }
                if((parede2 > parede1) && (parede2 > parede3)) {
                    diga("A parede 02 tem mais tijolos");
                }
                if((parede3 > parede2) && (parede3 > parede1)) {
                    diga(" A parede 03 tem mais tijolos");
                }
                                            
                if((parede1 < parede2) && (parede1 < parede3)) {
                    diga("A parede 01 tem menos tijolos");
                }
                if((parede2 < parede1) && (parede2 < parede3)) {
                    diga("A parede 02 tem menos tijolos");
                }
                if((parede3 < parede2) && (parede3 < parede1)) {
                    diga("A parede 03 tem menos tijolos");
                }
                                    
                totalDeTijolos = parede1 + parede2 + parede3;
                diga("O numero total de tijolos � de "+ totalDeTijolos);
                
                media = totalDeTijolos / 3;
                diga("A m�dia de tijolos � " + media);
    
        }

 

    public ImageIcon buildImage() {

 

        return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
    }

 

    public static void main(String[] args) {
        MundoVisual.iniciar("Prova02ex2.xml");

 

    }

 

}