import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista4Ex03 extends Furbot {


	Numero personagemNumero = new Numero();
	int valor = 0;
	boolean a =false;

	public void voltarInicio() {
		while (!ehFim(ESQUERDA)) {
			andarEsquerda();
		}
		while (!ehFim(ACIMA)) {
			andarAcima();
		}
	}

	public void manipulaNumeros(Direcao direcao) {
		if (!ehVazio(direcao)) {
			personagemNumero = getObjeto(direcao);
			String valorDoPersonagem = personagemNumero.toString();
			valor = Integer.parseInt(valorDoPersonagem);
			for (int i = 1; i <= 10; ++i) {
				for (int j = 1; j <= 10; ++j) {
					if (j * i == valor) {
						a=true;
						diga("N�mero: " + valor);
						diga(i + " x " + j);
					}
				}
			}
		}
		if (a==false) {
			diga("N�mero n�o pertence a tabuada.");
		}
	}

	public void inteligencia() throws Exception {

		// volto para o 0,0 para fazer o passeio pelo mundo
		voltarInicio();
		manipulaNumeros(AQUIMESMO);

		boolean repetir;
		repetir = true;

		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				manipulaNumeros(DIREITA);
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				manipulaNumeros(ABAIXO);
				andarAbaixo();
				while (!ehFim(ESQUERDA)) {
					manipulaNumeros(ESQUERDA);
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					manipulaNumeros(ABAIXO);
					andarAbaixo();
				} else {
					repetir = false;
				}

			} else {
				repetir = false;
			}
		}

		this.limparConsole();

	}

	public ImageIcon buildImage() {
		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista4Ex03.xml");

	}

}
