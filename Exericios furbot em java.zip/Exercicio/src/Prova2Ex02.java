import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;

public class Prova2Ex02 extends Furbot {

	//Equipe01
	// Amanda Detofol
	// Felipe
	//Iago
	//Stephani
	
	int tijolosParede = 0;
	// a variavel controlador eh usada para verificar se o robo passou pela situacao
	// --| para que quando o mundo tiver uma casa a menos nao de erro		
	boolean controlador = false;

	public void contaTijolos() {
		
		while (ehVazio(ACIMA)) {
			
			while (!ehVazio(DIREITA)) {
				tijolosParede = tijolosParede+1;
				andarAcima();
			}
			
			
			if (!ehVazio(AQUIMESMO)) {
				andarDireita();
				andarDireita();
				andarAbaixo();

			}
			while (!ehVazio(ESQUERDA)) {
				
				
				//vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as parede
				if (!ehFim(ABAIXO)) {
					andarAbaixo();
				} else {
					diga("Não posso continuar o passeio.");
					diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
					break;
				}
			}
			if(!ehFim(ABAIXO)) {
			andarEsquerda();
			andarEsquerda();
			andarAcima();
			controlador = true;
			break;
			}
		}

		if (controlador == false) {
			while (!ehVazio(ACIMA)) {
				if (ehVazio(ESQUERDA)) {
					while (!ehVazio(ACIMA)) {
						tijolosParede = tijolosParede+1;
						andarEsquerda();
					}

					andarAcima();
					andarAcima();
					andarDireita();
					andarDireita();

					
					if (!ehVazio(AQUIMESMO)) {
						andarDireita();
					}

					while (!ehVazio(ABAIXO)) {
						tijolosParede = tijolosParede+1;
						andarDireita();
					}

					
					// vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
					if (!ehFim(ABAIXO)) {
						andarAbaixo();
					} else {
						diga("Não posso continuar o passeio.");
						diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
						break;
					}

					while (!ehVazio(ESQUERDA)) {
						andarAbaixo();
						tijolosParede = tijolosParede+1;
					
						// vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
						if (!ehFim(ABAIXO)) {
							andarAbaixo();
						} else {
							diga("Não posso continuar o passeio.");
							diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
							break;
						}
					}
					if(!ehFim(ABAIXO)) {
					andarEsquerda();
					andarEsquerda();
					andarAcima();
					}
				} else {
					
					while (!ehVazio(ACIMA)) {
						tijolosParede = tijolosParede+1;
						andarDireita();
					}		
					andarAcima();
					andarAcima();
					andarEsquerda();
					andarEsquerda();
					andarEsquerda();
					
					
					while (!ehVazio(ABAIXO)) {
						tijolosParede = tijolosParede+1;
						andarEsquerda();
					}
					andarAbaixo();
					andarAbaixo();
					
					
					if (!ehVazio(DIREITA))
						tijolosParede = tijolosParede+1;
					//vejo se nao eh fim abaixo, se for fim quer dizer que cheguei no limite do mundo e nao posso dar a volta completa e contar as paredes
					if (!ehFim(ABAIXO)) {
						andarAbaixo();
					} else {
						diga("Não posso continuar o passeio.");
						diga("Estimo que a parede tenha " + tijolosParede + " tijolos");
						break;
					}
					andarDireita();
					andarDireita();
					andarAcima();
				}
				break;
			}
		}

		diga("A parede era composta por " + tijolosParede + " tijolos.");
	}

	public void inteligencia() {

		limparConsole();
		tijolosParede = 0;
		contaTijolos();
		
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Prova2Ex02.xml");

	}

}