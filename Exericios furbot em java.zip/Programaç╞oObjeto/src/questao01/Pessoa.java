package questao01;

import java.util.Scanner;

public class Pessoa {
	private double peso;
	private double altura;
	private String nome;
	
	public double calcularImc() {
		return peso/(altura*altura);
	}
	
	public void setPeso(double peso) {
		if (peso<0) {
			throw new RuntimeException("O peso n�o pode ser negativo");
		}
		else 
		{
		this.peso = peso;}
	}
	
	public void setAltura(double altura) {
		if (altura<0) {
			throw new RuntimeException("A altura pode ser negativo");
		}
		else 
		{
		this.altura = altura;}
	}
	
	public void setNome(String nome) {
		this.nome=nome;
	}
	
	public double getPeso() {
		return peso;
	}
	
	public double getAltura() {
		return altura;
	}
	
	public String getNome() {
		return nome;
	}



}
