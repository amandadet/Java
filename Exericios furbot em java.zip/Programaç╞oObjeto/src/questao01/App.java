package questao01;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pessoa p1;
		p1 = new Pessoa();
		
		p1.peso = 80;
		p1.altura = 1.80;
		
		double imc;
		imc=p1.calcularImc();
		
		System.out.println("Este � o imc " + imc);
		
		
	}

}
