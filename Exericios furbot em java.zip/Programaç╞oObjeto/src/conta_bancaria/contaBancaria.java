package conta_bancaria;

public class contaBancaria {
	
	private String numero;
	private String titular;
	private double saldo;
	
	public  String getNumero() {
		return numero;
	}
	
	public void setNumero (String numero) {
		this.numero=numero;
	}
	
	public String getTitular() {
		return titular;
	}
	
	public void setTitular(String titular) {
		this.titular = titular;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void depositar(double valor) {
		if (valor<=0) {
			throw new RuntimeException("N�o � possivel depositar um valor negativo ou nulo");
		} else {
			saldo = saldo+valor;
		}
	}
	
	public void sacar(double valor) {
		if (saldo < valor || valor<=0) {
			throw new RuntimeException("Saldo insuficiente para fazer este saque, por favor, verifique. Valor n�o pode ser negativo ou nulo.");
		} else {
			saldo = saldo-valor;
		}
	}
	
	public void transferir (contaBancaria contaDestino , double valor) {
		this.sacar(valor);
		contaDestino.depositar(valor);
	}

}
