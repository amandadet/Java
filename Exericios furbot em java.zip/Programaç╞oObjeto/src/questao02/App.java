package questao02;

import java.util.Scanner;

import questao01.Pessoa;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pessoa p1;
		p1 = new Pessoa();

		System.out.println("Digite seu peso: ");
		Scanner pesoUsuario = new Scanner(System.in);
		double p = Double.parseDouble(pesoUsuario.nextLine());
		p1.peso = p;
		
		System.out.println("Digite sua altura: ");
		Scanner alturaUsuario = new Scanner(System.in);
		double a = Double.parseDouble(pesoUsuario.nextLine());
		p1.altura = a;
		
		double imc;
		imc = p1.calcularImc();
		
		System.out.println("Seu IMC � " + imc);
		
	}

}
