package questao04;

import java.util.Scanner;

public class Pessoa {
	private double peso;
	private double altura;
	private String nome;
	
	public double calcularImc() {
		return peso/(altura*altura);
	}
	
	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public void setNome(String nome) {
		this.nome=nome;
	}
	
	public double getPeso() {
		return peso;
	}
	
	public double getAltura() {
		return altura;
	}
	
	public String getNome() {
		return nome;
	}



}