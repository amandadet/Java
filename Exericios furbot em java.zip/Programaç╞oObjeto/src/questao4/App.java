package questao4;

import java.util.Scanner;

import questao01.Pessoa;

public class App {

	public static void main(String[] args) {
		int contador =0;
		int i = 2;
		String lista[];
		lista = new String[3];
		
		while (contador!=3) {
			Pessoa p1;
			p1 = new Pessoa();
			String conteudo;
					
			System.out.println("Digite seu nome: ");
			Scanner nomeUsuario = new Scanner(System.in);
			p1.setNome(nomeUsuario.nextLine());
			
			System.out.println("Digite seu peso: ");
			Scanner pesoUsuario = new Scanner(System.in);
			double p = Double.parseDouble(pesoUsuario.nextLine());
			p1.setPeso(p);
			
			System.out.println("Digite sua altura: ");
			Scanner alturaUsuario = new Scanner(System.in);
			double a = Double.parseDouble(pesoUsuario.nextLine());
			p1.setAltura(a);
			
			double imc;
			imc = p1.calcularImc();
						
			conteudo = "Nome: " + p1.getNome() + " Peso: " + p1.getPeso() + " Altura: " + p1.getAltura() + " IMC: " + imc ;
			lista[contador]=conteudo;
			
			contador++;
			
		}
		
		while(i>=0) {
			System.out.println(lista[i]);
			i--;
		}
	
		
	}

}
