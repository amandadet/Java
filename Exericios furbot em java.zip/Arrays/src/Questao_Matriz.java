import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Questao_Matriz extends Furbot {
	Numero personagemNumero = new Numero();
	int soma = 0;
	boolean repetir = true;
	public static final int MAX_LIN = 8;
	public static final int MAX_COL = 8;
	int[][] posicoes = new int[MAX_LIN][MAX_COL];
	int[][] segunda_matriz = new int[MAX_LIN][MAX_COL];

	void marcaPosicao() {
		if (ehVazio(AQUIMESMO))
			posicoes[getY()][getX()] = 0;
		else if (ehObjetoDoMundoTipo("Numero", AQUIMESMO) == true) {
			posicoes[getY()][getX()] = 5;
		} else {
			posicoes[getY()][getX()] = 9;
		}
	}

	void montaSegundaMatriz() {
		if (ehObjetoDoMundoTipo("Numero", AQUIMESMO)) {
			personagemNumero = getObjeto(AQUIMESMO);
			String valorDoPersonagem0 = personagemNumero.toString();
			int valor = Integer.parseInt(valorDoPersonagem0);
			segunda_matriz[getY()][getX()] = valor;
		} else {
			segunda_matriz[getY()][getX()] = 0;
		}
	}

	void realizaSoma() {
		// devo fazer as operacoes encima de segunda_matriz e armazenar em soma_valores
		int maiorSoma = 0;
		int linhaComMaiorSoma = 0;
		for (int linha = 0; linha < MAX_LIN; linha++) {
			soma = 0;
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				soma = segunda_matriz[linha][coluna] + soma;
				if (soma >= maiorSoma) {
					maiorSoma = soma;
					linhaComMaiorSoma = linha;
				}

			}
			System.out.print("Linha " + linha + "  Soma = " + soma);
			System.out.println();
		}
		System.out.println(" ");
		System.out.println("A linha com maior soma � linha " + linhaComMaiorSoma + " com o valor " + maiorSoma);
	}

	public void inteligencia() throws Exception {
		diga("exercicio 8a");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				marcaPosicao();
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				marcaPosicao();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					marcaPosicao();
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					marcaPosicao();
					andarAbaixo();
				} else
					repetir = false;
			} else
				repetir = false;
		} // while

		// volto para o inicio
		while (!ehFim(ACIMA)) {
			andarAcima();
		}

		repetir = true;

		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				montaSegundaMatriz();
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				marcaPosicao();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					montaSegundaMatriz();
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					montaSegundaMatriz();
					andarAbaixo();
				} else
					repetir = false;
			} else
				repetir = false;
		} // while

		// mostro a primeira matriz
		System.out.println("RESULTADO DA PRIMEIRA ANALISE DA MATRIZ!");
		for (int linha = 0; linha < MAX_LIN; linha++) {
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				System.out.print(posicoes[linha][coluna] + ",");
			}
			System.out.println();
		}

		System.out.println(" ");
		// mostro a segunda matriz
		System.out.println("RESULTADO DA SEGUNDA ANALISE DA MATRIZ!");
		for (int linha = 0; linha < MAX_LIN; linha++) {
			for (int coluna = 0; coluna < MAX_COL; coluna++) {
				System.out.print(segunda_matriz[linha][coluna] + ",");
			}
			System.out.println();
		}

		System.out.println(" ");

		// mostro a soma
		realizaSoma();

	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Questao_Matriz.xml");

	}

}