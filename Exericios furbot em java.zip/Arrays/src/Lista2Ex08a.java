import javax.swing.ImageIcon;

import br.furb.furbot.Direcao;
import br.furb.furbot.Furbot;
import br.furb.furbot.MundoVisual;
import br.furb.furbot.Numero;
import br.furb.furbot.suporte.LoadImage;

public class Lista2Ex08a extends Furbot {
	
	boolean repetir = true;
	public static final int MAX_LIN = 8;
	public static final int MAX_COL = 8;
	int [][] posicoes =new int[MAX_LIN][MAX_COL];
	
	void marcaPosicao() {
		if (ehVazio(AQUIMESMO)) 
			posicoes[getX()][getY()] = 0;
		else {
			if ( ehObjetoDoMundoTipo("Parede", AQUIMESMO)  == true ) {
				posicoes[getX()][getY()] = 1;
			} else {
				if ( ehObjetoDoMundoTipo("Alien", AQUIMESMO)  == true ) {
					posicoes[getX()][getY()] = 2;
				} else {
					if ( ehObjetoDoMundoTipo("Tesouro", AQUIMESMO)  == true ) {
						posicoes[getX()][getY()] = 3;
					} else {
						if ( ehObjetoDoMundoTipo("Boolean", AQUIMESMO)  == true ) {
							posicoes[getX()][getY()] = 4;
						} else
							posicoes[getX()][getY()] = 9;
					}
				}
			}
		}
	}

	public void inteligencia() throws Exception {
		diga("exercicio 8a");
		while (repetir == true) {
			while (!ehFim(DIREITA)) {
				marcaPosicao();
				andarDireita();
			}
			if (!ehFim(ABAIXO)) {
				marcaPosicao();
				andarAbaixo();

				while (!ehFim(ESQUERDA)) {
					marcaPosicao();
					andarEsquerda();
				}
				if (!ehFim(ABAIXO)) {
					marcaPosicao();
					andarAbaixo();
				} else
					repetir = false;
			} else
				repetir = false;
		} // while
		
		for (int i = 0;i <MAX_LIN;i++) {
			for (int j = 0; j < MAX_COL;j++) {
				System.out.print(posicoes[j][i]+",");
			}
			System.out.println();
		}//

	}

	public ImageIcon buildImage() {

		return LoadImage.getInstance().getIcon("furbot(50x70).jpg");
	}

	public static void main(String[] args) {
		MundoVisual.iniciar("Lista2Ex08a.xml");

	}

}