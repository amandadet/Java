package contabancaria;

import java.util.Scanner;

public class App {
	public static void main(String[] args) {					
		ContaBancaria conta1 = new ContaBancaria();
		ContaBancaria conta2 = new ContaBancaria();
		
		System.out.println("Digite o número da conta 01: ");
		Scanner nc1 = new Scanner(System.in);
		conta1.setNumero(nc1.nextLine());
		
		System.out.println("Digite nome do titular da conta 01: ");
		Scanner tc1 = new Scanner(System.in);
		conta1.setTitular(tc1.nextLine());
		
		System.out.println("Digite o número da conta 02: ");
		Scanner nc2 = new Scanner(System.in);
		conta2.setNumero(nc2.nextLine());
		
		System.out.println("Digite nome do titular da conta 02: ");
		Scanner tc2 = new Scanner(System.in);
		conta2.setTitular(tc2.nextLine());
		
                conta1.depositar(100);
                ContaBancaria c2 =conta1;
                c2.depositar(150);
                System.out.println(conta1.getSaldo()+conta2.getSaldo());
                
		//a-efetue depositos de 1.000 e 700 na conta 01
		conta1.depositar(1000);
		conta1.depositar(700);
		
		//b-deposite 5000 na conta 2
		conta2.depositar(5000);
		
		//c-saque 3000 na conta 2
		conta2.sacar(3000);
		System.out.println("Depois de realizar o saque, o saldo da conta " + conta2.getNumero() + " eh " + conta2.getSaldo() );
		
		//d- transfira 1.800 da conta 01 para a conta 2
		conta1.transferir(conta2, 1800);
	
		
		//e-exibir o titular de cada conta com o saldo respectivo
		System.out.println("O titular da conta " + conta1.getNumero() + " eh " + conta1.getTitular() + " e o saldo dessa conta eh " + conta1.getSaldo() );
		System.out.println("O titular da conta " + conta2.getNumero() + " eh " + conta2.getTitular() + " e o saldo dessa conta eh " + conta2.getSaldo() );
				
	}

}

