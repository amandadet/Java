
package contabancaria;

/**
 * classe conta bancaria com as operações de saque, debito e transferencia
 * @author Usuario
 */
public class ContaBancaria {
    private String numero;
    private String titular;
    private double saldo;
    
    /**
    * Eh o metodo getter da variavel de intancia numero
    * @author Amanda Detofol Constante
    */
    public String getNumero(){
        return this.numero;
    }
    
    /**
    * Eh o metodo setter da variavel de intancia numero
    * @author Amanda Detofol Constante
    */
    public void setNumero(String numero){
        this.numero = numero;
    }
    
    /**
    * Eh o metodo getter da variavel de intancia titular
    * @author Amanda Detofol Constante
    */
    public String getTitular(){
       return this.titular;
    }
    
    /**
    * Eh o metodo setter da variavel de intancia titular
    * @author Amanda Detofol Constante
    */
    public void setTitular(String titular){
        this.titular = titular;
    }
    
    /**
    * Eh o metodo getter da variavel de intancia saldo
    * @author Amanda Detofol Constante
    */
    public double getSaldo(){
        return this.saldo;
    }
    
    /**
    * Eh o metodo de deposito de valores da conta bancaria. Seu objetivo e somar
    * um valor ao saldo. O valor que o usuario deseja depositar nao pode ser 0 ou nulo.
    * @author Amanda Detofol Constante
    */
    public void depositar(double valor){
        if (valor<=0){
            throw new RuntimeException("O valor depositado precisa ser maior do que 0! ");
        } else {
            this.saldo+=valor;
        }
    }
    
    /**
    * Eh o metodo de saque de valores da conta bancaria. Seu objetivo e diminuir
    * um valor do saldo. O valor que o usuario deseja sacar nao pode ser 0 ou nulo.
    * @author Amanda Detofol Constante
    */
    public void sacar(double valor){
        if (valor<=0 || saldo<valor){
            throw new RuntimeException("O valor sacado precisa ser maior do que 0! ");
        } else {
            this.saldo-=valor;
        }
    }
    
    /**
    * Eh o metodo de transferencia da conta bancaria. Seu objetivo eh transferir uma
    * quantia de uma conta para outra.
    * @author Amanda Detofol Constante
    */
    public void transferir(ContaBancaria c1 ,double valor){
        this.sacar(valor);
        c1.depositar(valor);
    }
    
}
