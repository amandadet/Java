
package model;

public class Estadia {
    private int horaEntrada;
    private int horaSaida;
    private boolean finalSemana;

    public Estadia() {
    }

    public Estadia(int horaEntrada, int horaSaida, boolean finalSemana) {
        setHoraEntrada(horaEntrada);
        setHoraSaida(horaSaida);
        this.finalSemana = finalSemana;
    }
    
    public int getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(int horaEntrada) {
        if (horaEntrada<0 || horaEntrada>24){
            throw new RuntimeException("O valor hora deve respeitar o intervalo 0-24");
        }else{
            this.horaEntrada = horaEntrada;
        }
    }

    public int getHoraSaida() {
        return horaSaida;
    }

    public void setHoraSaida(int horaSaida) {
        if (horaSaida<0 || horaSaida>24){
            throw new RuntimeException("O valor hora deve respeitar o intervalo 0-24");
        }else{
               this.horaSaida = horaSaida;
        }
    }
    
    public boolean isFinalSemana(){
        return this.finalSemana;
    }
    
    public void setFinalSemana(boolean finalSemana){
        this.finalSemana=finalSemana;
    }
    
    public int calcularTempoEstadia(){
        if (horaSaida>horaEntrada){
            return horaSaida-horaEntrada;
        } else {
            return (horaEntrada-12)-horaSaida;
        }
    }
    
    public double calcularValorPagar(){
       int horas = calcularTempoEstadia();
       boolean finalDeSemana = isFinalSemana();
       double valorPagar = 0;
       
       if (horas<=4 && finalDeSemana == true ){
           return valorPagar=10.00;
       } 
                  
       if (horas<=4 && finalDeSemana == false){
           return valorPagar=8.00;
       }
       
       if (horas>4 && finalDeSemana == true ){
           int adicional = horas-4;
           return valorPagar=10.00 + (adicional*4.00);
       } 
       
       if (horas>4 && finalDeSemana == false){
           int adicional = horas-4;
           return valorPagar=8.00 + (adicional*3.00);
       }
       
       return valorPagar;
       
    }
    
    
}
