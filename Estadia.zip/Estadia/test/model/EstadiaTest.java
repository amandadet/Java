/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Usuario
 */
public class EstadiaTest {
    
    public EstadiaTest() {
    }

    @Test (expected = RuntimeException.class)
    public void testHoraDeEntradaNegativa() {
        Estadia est1 = new Estadia(-5,6,false);       
    }
    
    @Test (expected = RuntimeException.class)
    public void testVerificarHoraEntradaSuperior() {
        Estadia est1 = new Estadia(30,6,false);       
    }
    
     @Test (expected = RuntimeException.class)
    public void testHoraDeSaidaNegativa() {
        Estadia est1 = new Estadia(4,-5,false);       
    }
    
    @Test (expected = RuntimeException.class)
    public void testVerificarHoraSaidaSuperior() {
        Estadia est1 = new Estadia(6,30,false);       
    }
    
     @Test 
    public void testVerificarCalculoEstadia() {
        Estadia est1 = new Estadia(10,15,false); 
        int resultado = est1.calcularTempoEstadia();
        assertEquals(resultado,5);
    }
    
    @Test 
    public void testVerificarCalculoEstadia1() {
        Estadia est1 = new Estadia(20,2,false); 
        int resultado = est1.calcularTempoEstadia();
        assertEquals(resultado,6);
    }
    
     @Test 
    public void testVerificarValorPagar() {
        Estadia est1 = new Estadia(20,22,false); 
        double resultado = est1.calcularValorPagar();
        assertEquals(resultado,8.0,0);
    }
    
    @Test 
    public void testVerificarValorPagar1() {
        Estadia est1 = new Estadia(17,23,false); 
        double resultado = est1.calcularValorPagar();
        assertEquals(resultado,14.0,0);
    }
    
    @Test 
    public void testVerificarValorPagarFinalSemana() {
        Estadia est1 = new Estadia(18,20,true); 
        double resultado = est1.calcularValorPagar();
        assertEquals(resultado,10.0,0);
    }
    
    @Test 
    public void testVerificarValorPagarFinalSemana1() {
        Estadia est1 = new Estadia(17,23,true); 
        double resultado = est1.calcularValorPagar();
        assertEquals(resultado,18.0,0);
    }
}
