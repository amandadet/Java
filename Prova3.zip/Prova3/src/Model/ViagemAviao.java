
package Model;

import java.util.ArrayList;


public class ViagemAviao {
   private double capacidade;
   private ArrayList<Pesavel> itensEmbarcados = new ArrayList<>();

    public double getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(double capacidade) {
        this.capacidade = capacidade;
    }

    public Pesavel getItensEmbarcados() {
        return (Pesavel) itensEmbarcados;
    }

    public void embarcar(Pesavel p){
        itensEmbarcados.add(p);
    }
    
    public double calcularPeso(){
        double pesoTotal = 0;
        for (Pesavel p : itensEmbarcados){
            pesoTotal += p.getPeso();
        }     
        return pesoTotal;
    }
   
}
