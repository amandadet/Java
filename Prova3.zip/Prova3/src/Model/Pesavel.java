
package Model;

public interface Pesavel {
    public void setPeso(double peso);
    public double getPeso();
}
