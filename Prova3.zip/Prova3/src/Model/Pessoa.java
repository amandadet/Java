
package Model;


public class Pessoa {
    private String nome;
    private double peso;

    Pessoa(String nome, double peso){
        this.nome=nome;
        this.peso=peso;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
}
