
package Model;


public class Quadrado extends Retangulo{
    
    public Quadrado(int medida) {
        super(medida, medida);
    }
    
}
