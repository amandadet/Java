
package Model;


public class Triangulo extends Figura{
    private int lado1; //a
    private int lado2; //b
    private int lado3; //c
    
    double p = (lado1+lado2+lado3)/2;
    
    Triangulo(int lado1, int lado2, int lado3){
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }
    
    
    @Override
    public double calcularArea() {
        return Math.sqrt(p*(p - this.lado1)*(p-this.lado2)*(p-this.lado3));
    }
    
}