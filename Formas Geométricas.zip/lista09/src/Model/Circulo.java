
package Model;


public class Circulo extends Figura{
    private int raio;
    
    Circulo (int raio){
        this.raio = raio;
    }
    
    @Override
    public double calcularArea() {
        return (this.raio*this.raio)*3.14;
    }
    
}
