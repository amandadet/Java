
package Model;

public class MensalidadeEnsino implements Pagavel {

    private int nrCreditos;
    private double precoCreditos;

    public int getNrCreditos() {
        return nrCreditos;
    }

    public void setNrCreditos(int nrCreditos) {
        this.nrCreditos = nrCreditos;
    }

    public double getPrecoCreditos() {
        return precoCreditos;
    }

    public void setPrecoCreditos(double precoCreditos) {
        this.precoCreditos = precoCreditos;
    }
    
    @Override
    public double calcularValorPagar() {
        return nrCreditos*precoCreditos; //To change body of generated methods, choose Tools | Templates.
    }
    
}
