
package Model;

import java.util.ArrayList;

public interface Pagavel {
    double calcularValorPagar();
}
