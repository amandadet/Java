
package Model;

public class ContaAgua implements Pagavel {
    private int metrosCubicos;
    private double precoMetrosCubicos;
    
    public int getMetrosCubicos() {
        return metrosCubicos;
    }

    public void setMetrosCubicos(int metrosCubicos) {
        this.metrosCubicos = metrosCubicos;
    }

    public double getPrecoMetrosCubicos() {
        return precoMetrosCubicos;
    }

    public void setPrecoMetrosCubicos(double precoMetrosCubicos) {
        this.precoMetrosCubicos = precoMetrosCubicos;
    }
    

    @Override
    public double calcularValorPagar() {
        return metrosCubicos*precoMetrosCubicos; //To change body of generated methods, choose Tools | Templates.
    }
}
