
package model;

public enum TipoDespesa {
    DESLOCAMENTO,
    HOSPEDAGEM,
    REFEICAO;
}
