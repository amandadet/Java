
package model;

import java.util.ArrayList;


public class Viagem {
    private double adiantamento;
    private ArrayList<Despesa> despesas = new ArrayList<>();
    
    public void inserirDespesa(Despesa despesa){   
        despesas.add(despesa);
    }
    
    public void removerDespesa(Despesa despesa){
        despesas.remove(despesa);
    }
    
    public ArrayList<Despesa> obterDespesas(){
        return despesas;
    }
    
    public double calcularValorViagem(){
        double valor = 0;
        for(Despesa umaDespesa:despesas){
            valor += umaDespesa.getValor();
        }
       return valor;
    }

    public double getAdiantamento() {
        return adiantamento;
    }
    
    public double calcularValorDevolverFuncionario(){
        double total=0;
        
        for(Despesa d: despesas){
            if (d.getTipo()==TipoDespesa.REFEICAO){
                total += Math.min(30.00 , d.getValor());
            }
            else {
            total+= d.getValor();}
        }        
        return adiantamento - total;
    }

    public void setAdiantamento(double adiantamento) {
        if (adiantamento<0){
            throw new RuntimeException("O valor não pode ser zero");
        }
        this.adiantamento = adiantamento;
    }
}
