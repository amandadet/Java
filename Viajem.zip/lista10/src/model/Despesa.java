
package model;


public class Despesa {
    private double valor;
    private TipoDespesa tipo;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if (valor<0){
            throw new RuntimeException("O valor não deve ser inferior a zero!"); 
        }
        this.valor = valor;
    }

    public TipoDespesa getTipo() {
        return tipo;
    }

    public void setTipo(TipoDespesa tipo) {
        this.tipo = tipo;
    }
    
}
