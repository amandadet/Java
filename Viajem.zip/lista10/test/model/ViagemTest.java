
package model;

import org.junit.Test;
import static org.junit.Assert.*;


public class ViagemTest {
    
    public ViagemTest() {
    }

    @Test
    public void caso1ConferirSeOMetodoCalcularValorViagemCalculaDespesasDiversas() {
        Viagem viagem = new Viagem();
        viagem.setAdiantamento(1200.00);
        //Uma despesa de deslocamento de R$ 500,00
        Despesa despesa1 = new Despesa();
        despesa1.setTipo(TipoDespesa.DESLOCAMENTO);
        despesa1.setValor(500.00);
        
        //Uma despesa de hospedagem de R$ 600,00
        Despesa despesa2 = new Despesa();
        despesa2.setTipo(TipoDespesa.HOSPEDAGEM);
        despesa2.setValor(600.00);
        
        //Duas despesas de refeição, de R$ 20,00 e R$
        //25,00, respectivamente
        
        Despesa despesa3 = new Despesa();
        despesa3.setTipo(TipoDespesa.REFEICAO);
        despesa3.setValor(20.00);
        
        Despesa despesa4 = new Despesa();
        despesa4.setTipo(TipoDespesa.REFEICAO);
        despesa4.setValor(25.00);
        
        viagem.inserirDespesa(despesa1);
        viagem.inserirDespesa(despesa2);
        viagem.inserirDespesa(despesa3);
        viagem.inserirDespesa(despesa4);
        
        double resultado = viagem.calcularValorViagem();
        
        assertEquals(1145.00,resultado,0.1);
       
    }
    
    @Test
    public void caso2ConferirSeOMetodoCalcularValorFuncionarioConsideraDespesasDiversas() {
        Viagem viagem = new Viagem();
        viagem.setAdiantamento(1200.00);
        //Uma despesa de deslocamento de R$ 500,00
        Despesa despesa1 = new Despesa();
        despesa1.setTipo(TipoDespesa.DESLOCAMENTO);
        despesa1.setValor(500.00);
        
        //Uma despesa de hospedagem de R$ 600,00
        Despesa despesa2 = new Despesa();
        despesa2.setTipo(TipoDespesa.HOSPEDAGEM);
        despesa2.setValor(600.00);
        
        //Duas despesas de refeição, de R$ 20,00 e R$
        //25,00, respectivamente
        
        Despesa despesa3 = new Despesa();
        despesa3.setTipo(TipoDespesa.REFEICAO);
        despesa3.setValor(20.00);
        
        Despesa despesa4 = new Despesa();
        despesa4.setTipo(TipoDespesa.REFEICAO);
        despesa4.setValor(25.00);
        
        viagem.inserirDespesa(despesa1);
        viagem.inserirDespesa(despesa2);
        viagem.inserirDespesa(despesa3);
        viagem.inserirDespesa(despesa4);
        
        double resultado = viagem.calcularValorDevolverFuncionario();
        
        assertEquals(55.00,resultado,0.1);
       
    }
    
      @Test
    public void caso3ConferirSeOMetodoCalcularValorFuncionarioConsideraDespesasDiversas() {
        Viagem viagem = new Viagem();
        viagem.setAdiantamento(1000.00);
        //Uma despesa de deslocamento de R$ 500,00
        Despesa despesa1 = new Despesa();
        despesa1.setTipo(TipoDespesa.DESLOCAMENTO);
        despesa1.setValor(200.00);
        
        //Uma despesa de hospedagem de R$ 600,00
        Despesa despesa2 = new Despesa();
        despesa2.setTipo(TipoDespesa.HOSPEDAGEM);
        despesa2.setValor(600.00);
        
        //Duas despesas de refeição, de R$ 20,00 e R$
        //25,00, respectivamente
        
        Despesa despesa3 = new Despesa();
        despesa3.setTipo(TipoDespesa.REFEICAO);
        despesa3.setValor(40.00);
        
        Despesa despesa4 = new Despesa();
        despesa4.setTipo(TipoDespesa.REFEICAO);
        despesa4.setValor(35.00);
        
        Despesa despesa5 = new Despesa();
        despesa5.setTipo(TipoDespesa.REFEICAO);
        despesa5.setValor(27.00);
        
        viagem.inserirDespesa(despesa1);
        viagem.inserirDespesa(despesa2);
        viagem.inserirDespesa(despesa3);
        viagem.inserirDespesa(despesa4);
        viagem.inserirDespesa(despesa5);
        
        double resultado = viagem.calcularValorDevolverFuncionario();
        
        assertEquals(113.00,resultado,0.1);
       
    }
    
}
