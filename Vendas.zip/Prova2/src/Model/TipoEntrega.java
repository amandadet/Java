
package Model;


public enum TipoEntrega {
    RETIRADA_LOCAL,
    SEDEX,
    ENCOMENDA_PAC;
}
