
package Model;

import java.util.ArrayList;
public class Venda {
    private TipoEntrega tipoentrega;
    private ArrayList<Produto> produtos = new ArrayList<>();
    
    public TipoEntrega getTipoEntrega() {
        return tipoentrega;
    }

    public void setTipoEntrega(TipoEntrega tipoentrega) {
        this.tipoentrega = tipoentrega;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void inserirProduto(Produto produto){
        produtos.add(produto);
    }
    
    public double calcularValorProdutos(){
        double total =0;
        for (Produto p: produtos){
            total += p.getValor();
        }
        return total;
    }
    
    public double calcularValorEntrega(){
        double valorEntrega =0;
        for (Produto p: produtos){
            if (this.tipoentrega == null){
                throw new RuntimeException("É preciso definir o tipo da entrega!");
            }else {

                if (this.getTipoEntrega() == TipoEntrega.RETIRADA_LOCAL){
                    valorEntrega = 0.0;
                } 

                if (this.getTipoEntrega() == TipoEntrega.ENCOMENDA_PAC){
                    valorEntrega = 7.79;
                }

                 if (this.getTipoEntrega() == TipoEntrega.SEDEX){
                    valorEntrega = 5.00 + ((p.getPeso()/200)*1.99);
                }

            }
        }
        return valorEntrega;
    }
     
     
}
