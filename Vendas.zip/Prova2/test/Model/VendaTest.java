
package Model;

import org.junit.Test;
import static org.junit.Assert.*;


public class VendaTest {
    
    public VendaTest() {
    }

    @Test
    public void caso1ConferirSeEhComputadoOPrecoDeTodosOsProdutosDaVenda() {
        Produto p1 = new Produto("P1",200,100.00);
        Produto p2 = new Produto("P2",200,35.00);
        Produto p3 = new Produto("P3",200,80.00);
        
        Venda v = new Venda();
        v.inserirProduto(p1);
        v.inserirProduto(p2);
        v.inserirProduto(p3);
        
        double result = v.calcularValorProdutos();
        
        assertEquals( 215.00, result, 0.01);
        
    }
    
     @Test
     public void caso2ConferirSeEhCalculadoCorretoViaSedex() {
        Produto p1 = new Produto("P1",500,100.00);
        Produto p2 = new Produto("P2",600,35.00);
        Produto p3 = new Produto("P3",200,80.00);
        
        Venda v = new Venda();
        v.setTipoEntrega(TipoEntrega.SEDEX);
        v.inserirProduto(p1);
        v.inserirProduto(p2);
        v.inserirProduto(p3);
        
        double result = v.calcularValorEntrega();
        
        assertEquals( 16.94, result, 0.01);
        
    }
   
    @Test (expected = RuntimeException.class)
     public void caso3ConferirSeEhRecusadoCalculoQuandoNaoDefineEntrega() {
        Produto p1 = new Produto("P1",500,100.00);

        Venda v = new Venda();
        v.inserirProduto(p1);
        double result = v.calcularValorEntrega();
        
    }
     
}
